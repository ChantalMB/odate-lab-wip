"use strict";
(self["webpackChunkjlab_cell_run"] = self["webpackChunkjlab_cell_run"] || []).push([["lib_index_js"],{

/***/ "./lib/index.js"
/*!**********************!*\
  !*** ./lib/index.js ***!
  \**********************/
(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _jupyterlab_notebook__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @jupyterlab/notebook */ "webpack/sharing/consume/default/@jupyterlab/notebook");
/* harmony import */ var _jupyterlab_notebook__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_notebook__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @jupyterlab/ui-components */ "webpack/sharing/consume/default/@jupyterlab/ui-components");
/* harmony import */ var _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_1__);


const CommandIds = {
    /**
     * Command to render a markdown cell.
     */
    renderMarkdownCell: 'toolbar-button:render-markdown-cell',
    /**
     * Command to run a code cell.
     */
    runCodeCell: 'toolbar-button:run-code-cell'
};
/**
 * Initialization data for the @jupyterlab-examples/cell-toolbar extension.
 */
const plugin = {
    id: 'jlab_cell_run:plugin',
    description: 'A JupyterLab extension to add cell toolbar buttons.',
    autoStart: true,
    requires: [_jupyterlab_notebook__WEBPACK_IMPORTED_MODULE_0__.INotebookTracker],
    activate: (app, tracker) => {
        const { commands } = app;
        /* Adds a command enabled only on code cell */
        commands.addCommand(CommandIds.runCodeCell, {
            icon: _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_1__.runIcon,
            caption: 'Run a code cell',
            execute: () => {
                commands.execute('notebook:run-cell');
            },
            isVisible: () => { var _a; return ((_a = tracker.activeCell) === null || _a === void 0 ? void 0 : _a.model.type) === 'code'; }
        });
        /* Adds a command enabled only on markdown cell */
        commands.addCommand(CommandIds.renderMarkdownCell, {
            icon: _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_1__.markdownIcon,
            caption: 'Render a markdown cell',
            execute: () => {
                commands.execute('notebook:run-cell');
            },
            isVisible: () => { var _a; return ((_a = tracker.activeCell) === null || _a === void 0 ? void 0 : _a.model.type) === 'markdown'; }
        });
    }
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (plugin);


/***/ }

}]);
//# sourceMappingURL=lib_index_js.56645040c60c63087d21.js.map